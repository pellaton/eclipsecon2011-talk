package com.google.eclipse.mechanic.ext;

import com.google.eclipse.mechanic.CompositeTask;

/**
 * A sample workspace mechanic task that can be pushed to the
 * mechanic in the file system.
 * 
 * <p>
 * To deploy this class task, copy the class file into 
 * {@code $scandir/com/google/eclipse/mechanic/ext/} where 
 * {@code $scandir} is a direcory configured as Workspace
 * Mechanic task source.  
 * </p>
 *  
 * @author Michael Pellaton
 * 
 * @see <a href="http://code.google.com/a/eclipselabs.org/p/workspacemechanic/wiki/TaskTypes">Task Types</a>
 * @see <a href="http://code.google.com/a/eclipselabs.org/p/workspacemechanic/wiki/ClassTasks">Class Tasks</a>
 */
public class ClassTask extends CompositeTask {

  /** {@inheritDoc} */
  @Override
  public String getDescription() {
    return "exmaple class task: description";
  }

  /** {@inheritDoc} */
  @Override
  public String getTitle() {
    return "example class task: title";
  }

  /** {@inheritDoc} */
  @Override
  public boolean evaluate() {
    return true;
  }

  /** {@inheritDoc} */
  @Override
  public void run() {
    System.out.println("example class task: run()");
  }
}
