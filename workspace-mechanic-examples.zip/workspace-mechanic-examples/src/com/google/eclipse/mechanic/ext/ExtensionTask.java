package com.google.eclipse.mechanic.ext;

import com.google.eclipse.mechanic.CompositeTask;

/**
 * A sample workspace mechanic task that is contributed through the 
 * extension point {@code com.google.eclipse.mechanic.tasks}.
 * 
 * <p>
 * To run this example task in Workspace Mechanic, run the containing
 * project as Eclipse Application.
 * </p>
 * 
 * @author Michael Pellaton
 * 
 * @see <a href="http://code.google.com/a/eclipselabs.org/p/workspacemechanic/wiki/TaskTypes">Task Types</a>
 * @see <a href="http://code.google.com/a/eclipselabs.org/p/workspacemechanic/wiki/ClassTasks">Class Tasks</a>
 * @see <a href="http://code.google.com/a/eclipselabs.org/p/workspacemechanic/wiki/TaskExtensionPoint">Task Extension Points</a>
 */
public class ExtensionTask extends CompositeTask {

  /** {@inheritDoc} */
  @Override
  public String getDescription() {
    return "example extension task: description";
  }

  /** {@inheritDoc} */
  @Override
  public String getTitle() {
    return "example extension task: title";
  }

  /** {@inheritDoc} */
  @Override
  public boolean evaluate() {
    return false;
  }

  /** {@inheritDoc} */
  @Override
  public void run() {
    System.out.println("example extension task: run()");
  }
}
