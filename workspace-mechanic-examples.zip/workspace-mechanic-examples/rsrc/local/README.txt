This directory contains an example of a local Workspace Mechanic task.


Put the epf file into a directory that is configured as Workspace Mechanic
task source.


For more information refer to:
http://code.google.com/a/eclipselabs.org/p/workspacemechanic/wiki/GettingStarted
http://code.google.com/a/eclipselabs.org/p/workspacemechanic/wiki/TaskTypes
http://code.google.com/a/eclipselabs.org/p/workspacemechanic/wiki/PreferenceTasks