This directory contains an example of a remote Workspace Mechanic task.


Put both the files "remote.epf" and "remote.json" on a http server and 
configure the URL to the JSON file as task source in Workspace Mechanic.

You need to adapt the URL of the epf file within the JSON file according
to your set-up.


For more information refer to:
http://code.google.com/a/eclipselabs.org/p/workspacemechanic/wiki/UrlScannerDesignDoc