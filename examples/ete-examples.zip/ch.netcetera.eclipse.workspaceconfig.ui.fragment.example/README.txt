This is an example fragment that shows how to preconfigure ETE.

To use this example:
1. install ETE
2. if you cannot connect to https://www.contrails.ch/econ2011/eclipse-config.epf 
   from your network: 
   - put the file eclipse-config.epf on some web server
   - adapt the URL in defaults.properties
3. build and deploy this fragment  (run as Eclipse Application or really deploy...)
 